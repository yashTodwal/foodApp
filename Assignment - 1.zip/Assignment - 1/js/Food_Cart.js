var cart = []; // Initialize an empty cart array

// Function to add an item to the cart
function addItem(name, price) {
    cart.push({ name: name, price: price, quantity: 1 });
    updateCart();
}

// Function to update the cart display
function updateCart() {
    var cartDiv = document.getElementById("cart");
    var totalSpan = document.getElementById("total");

    cartDiv.innerHTML = ""; // Clear the cart display
    var total = 0;

    cart.forEach(function (item, index) {
        var cartItem = document.createElement("div");
        cartItem.className = "cart-item";
        cartItem.innerHTML = '<span class="item-name">' + item.name + '</span>' +
                            '<input type="number" class="item-quantity" value="' + item.quantity + '" min="1" onchange="updateQuantity(' + index + ', this.value)">' +
                            '<span class="item-price">$' + (item.price * item.quantity).toFixed(2) + '</span>' +
                            '<button class="item-delete-button" onclick="deleteItem(' + index + ')">Delete</button>';
        cartDiv.appendChild(cartItem);

        total += item.price * item.quantity;
    });

    totalSpan.textContent = total.toFixed(2);
}

// Function to update item quantity
function updateQuantity(index, quantity) {
    cart[index].quantity = parseInt(quantity, 10);
    updateCart();
}

// Function to delete an item from the cart
function deleteItem(index) {
    cart.splice(index, 1);
    updateCart();
}

// Function to handle checkout
function checkout() {
    // Implement your checkout logic here, e.g., sending the order to a server
    alert("Order placed!");

    // Clear the cart
    cart = [];
    updateCart();
}

// Example: Add some items to the cart
addItem("Pizza", 10.99);
addItem("Burger", 5.49);
addItem("Pasta", 8.99);