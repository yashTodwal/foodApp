function placeOrder() {
    var pizzaQuantity = document.getElementById("pizza-quantity").value;
    var burgerQuantity = document.getElementById("burger-quantity").value;
    var pastaQuantity = document.getElementById("pasta-quantity").value;

    // You can calculate the total price and perform other actions here
    var totalPrice = (pizzaQuantity * 10) + (burgerQuantity * 5) + (pastaQuantity * 8);

    alert("Order placed!\nTotal Price: $" + totalPrice.toFixed(2));
}